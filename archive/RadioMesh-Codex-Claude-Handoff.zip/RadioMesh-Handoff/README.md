# RadioMesh — Projektübergabe

**Stand:** 31. Oktober 2026  
**Status:** Konzept / technische Evaluierung — noch kein funktionsfähiger eigener Code  
**Arbeitstitel:** RadioMesh (Name vor Veröffentlichung prüfen)

## Ziel in einem Satz

Ein offenes, plattformübergreifendes Mesh-Datennetz über KISS-/AX.25-kompatible Funkmodems, das **herkömmliche IPv4-Anwendungen (TCP/UDP/HTTP)** ebenso ermöglicht wie **Stations-/Diensteerkennung, Chat, kleine Funkseiten und optionales Store-and-Forward**.

## Getroffene Richtungsentscheidungen

1. **Normales IP muss ein Kernfeature bleiben**, nicht bloß ein späteres Gateway. Das Netz soll bereits existierende Programme ohne Anwendungspatches nutzbar machen.
2. **Linux und Windows direkt per USB an das Funkgerät**; Raspberry Pi Zero (2 W) ist *optional* für Dauerbetrieb, Mailbox, WLAN-Bridge und Relais.
3. Primärer erster Hardwarekandidat: **Quansheng UV-K5 V3 mit F4HWN Fusion/Labs KISS-TNC über USB-C**, experimentell und vor Entwicklungsfreigabe real zu prüfen.
4. **Bestehende Projekte nutzen:** `Packet.NET` als AX.25-/KISS-Kandidat; `pdn-net` für standardkonformes IP-over-AX.25; LinBPQ/BPQ für Interoperabilität; Reticulum/NomadNet/LXMF als optionale Integration.
5. **Eigenes Hauptrepository** für Orchestrierung, Discovery, Mesh-Routing, UI und native Dienste. `pdn-net` bei Bedarf **gezielt forken** (etwa Windows-Wintun), möglichst upstream zusammenarbeiten; nicht unnötig alles duplizieren.
6. **C#/.NET 10** für den gemeinsamen Kern; Linux-TUN und Windows-Wintun als Betriebssystem-Adapter; lokale Browseroberfläche.
7. **Offenes Amateurfunkprofil ohne Inhaltsverschlüsselung**; optionales verschlüsseltes Profil nur für **rechtlich geeignete** andere Transportmedien. Nicht auf Basis einer Frequenzbezeichnung allein von Zulässigkeit ausgehen.
8. Konzeptionell **kompakter nativer Chat und Dienstekatalog** neben transparentem IPv4, weil 1200 bit/s für typische Webanwendungen stark begrenzt sind.

## Dokumente

| Datei | Zweck |
|---|---|
| [`docs/PROJECT_HANDOFF.md`](docs/PROJECT_HANDOFF.md) | Vollständige Chat-Zusammenfassung, Anforderungen und Entscheidungen |
| [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) | Softwareebenen, Multi-Hop, IP-Zuordnung, Discovery, Sicherheit, Integration |
| [`docs/ROADMAP.md`](docs/ROADMAP.md) | Meilensteine und **testbare Akzeptanzkriterien** |
| [`docs/RESEARCH.md`](docs/RESEARCH.md) | Repositories, verifizierte Funktionen, Lizenzen, Unsicherheiten |
| [`docs/OPEN_QUESTIONS.md`](docs/OPEN_QUESTIONS.md) | Noch zu klärende technische und strategische Punkte |
| [`docs/START_PROMPT.md`](docs/START_PROMPT.md) | Fertige erste Arbeitsanweisung für Codex/Claude |
| [`AGENTS.md`](AGENTS.md) | Repo-Anweisungen für Coding Agents (Codex) |
| [`CLAUDE.md`](CLAUDE.md) | Projektzugang für Claude Code |

## Empfohlener Einstieg lokal

```bash
# In diesem Ordner arbeiten
cat docs/START_PROMPT.md
# Codex oder Claude Code im Projektordner starten; den Prompt übergeben.
```

**Nicht mit einer kompletten Eigenimplementierung anfangen.** Zuerst `Packet.NET`/`pdn-net` auschecken, Versionen/Lizenzen prüfen, Builds/Tests ausführen, APIs inspizieren und ein reproduzierbares Zwei-Knoten-Labortestsetup erstellen. Keine echte Funkaussendung in der ersten Phase.

## Erwartete erste Demo

Zwei simulierte Stationen A und B haben unterschiedliche IPv4-Adressen, teilen einen simulierten KISS/AX.25-Kanal, und ein einfacher HTTP-Client auf A kann **nachweisbar über die virtuelle Funkstrecke** einen minimalistischen HTTP-Server auf B erreichen. Für den ersten Prototyp ist auch ein kleiner UDP/ICMP-Test zulässig, wenn die vorhandene TCP-Tauglichkeit noch ungeklärt ist. Danach reale Quansheng-Hardware, Stationserkennung, Mehrhop.

> Diese Dateien sind eine **Planungs-/Agentenübergabe**, keine fertige lauffähige Implementierung und keine Aussage, dass alle externen Komponenten bereits untereinander getestet wurden.
